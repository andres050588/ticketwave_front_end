import { useEffect, useState } from "react"
import { Container, Row, Col, Button, Spinner, Alert } from "react-bootstrap"
import { useNavigate } from "react-router-dom"
import axios_api from "../api/api.js"
import TicketCard from "./TicketCard.js"

export default function FeaturedTickets() {
    const [tickets, setTickets] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const navigate = useNavigate()

    useEffect(() => {
        const fetchTickets = async () => {
            try {
                const response = await axios_api.get("/api/tickets")
                setTickets(response.data.slice(0, 6))
            } catch (error) {
                setError("Errore nel caricamento dei biglietti")
            } finally {
                setLoading(false)
            }
        }

        fetchTickets()
    }, [])

    return (
        <section className="bg-light py-5">
            <Container>
                <h2 className="mb-4 text-center">🎟️ Biglietti in Primo Piano</h2>
                {loading && <Spinner animation="border" />}
                {error && <Alert variant="danger">{error}</Alert>}

                <Row>
                    {tickets.map(ticket => (
                        <Col key={ticket.id} md={6} lg={4}>
                            <TicketCard ticket={ticket} />
                        </Col>
                    ))}
                </Row>

                {!loading && !error && tickets.length > 0 && (
                    <div className="text-center mt-4">
                        <Button variant="outline-primary" onClick={() => navigate("/tickets")}>
                            Vedi tutti i biglietti →
                        </Button>
                    </div>
                )}
            </Container>
        </section>
    )
}
