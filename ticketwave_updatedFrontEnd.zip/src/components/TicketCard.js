import { Card, Button } from "react-bootstrap"
import { useNavigate } from "react-router-dom"

export default function TicketCard({ ticket }) {
    const navigate = useNavigate()

    return (
        <Card className="mb-4 shadow-sm">
            {ticket.imageURL && <Card.Img variant="top" src={ticket.imageURL} alt={ticket.title} style={{ maxHeight: "200px", objectFit: "cover" }} />}
            <Card.Body>
                <Card.Title>{ticket.title}</Card.Title>
                <Card.Text> Prezzo: €{ticket.price}</Card.Text>
                <Card.Text>{new Date(ticket.eventDate).toLocaleDateString("it-IT")}</Card.Text>
                <Button variant="primary" className="w-100 mt-2" onClick={() => navigate(`/tickets/${ticket.id}`)}>
                    Vedi Dettagli
                </Button>
            </Card.Body>
        </Card>
    )
}
