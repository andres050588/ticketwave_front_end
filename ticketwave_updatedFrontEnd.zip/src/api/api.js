// src/api/api.js
import axios from "axios"

const axios_api = axios.create({
    baseURL: process.env.REACT_APP_API_URL,
    headers: {
        "Content-Type": "application/json"
    }
})

export default axios_api
