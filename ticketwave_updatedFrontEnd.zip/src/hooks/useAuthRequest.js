import { useNavigate } from "react-router-dom"
import { useCallback, useState } from "react"
import axios_api from "../api/api.js"

export const useAuthRequest = () => {
    const navigate = useNavigate()
    const [errorMessage, setErrorMessage] = useState(null)

    const authorizedRequest = useCallback(
        async (url, method = "get", config = {}) => {
            const token = localStorage.getItem("token")
            try {
                const baseURL = process.env.REACT_APP_API_URL?.replace(/\/$/, "") //|| "http://localhost:3001"
                const fullUrl = url.startsWith("http") ? url : `${baseURL}/${url.replace(/^\//, "")}`

                console.log("🚀 Sending request with config:", {
                    method,
                    url: fullUrl,
                    headers: {
                        ...(config.headers || {}),
                        ...(token && { Authorization: `Bearer ${token}` })
                    },
                    ...config
                })

                const response = await axios_api({
                    method,
                    url: fullUrl,
                    headers: {
                        ...(config.headers || {}),
                        ...(token && { Authorization: `Bearer ${token}` })
                    },
                    ...config
                })
                return response.data
            } catch (error) {
                const status = error.response?.status
                console.warn("[useAuthRequest] Errore chiamata:", status, url)

                if ([401, 403].includes(status)) {
                    if (window.location.pathname !== "/login") {
                        setErrorMessage("Sessione scaduta. Verrai reindirizzato al login.")
                        localStorage.removeItem("token")

                        setTimeout(() => {
                            navigate("/login")
                        }, 1500)
                    }
                } else if (status === 404) {
                    setErrorMessage("Risorsa non trovata.")
                } else {
                    setErrorMessage("Errore durante la richiesta.")
                }
                return null
            }
        },
        [navigate]
    )

    return { authorizedRequest, errorMessage }
}
