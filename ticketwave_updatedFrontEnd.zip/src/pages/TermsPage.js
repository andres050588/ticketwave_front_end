export default function TermsPage() {
    return (
        <div className="p-5">
            <h2>Termini e Condizioni</h2>
            <p>Qui troverai i termini e condizioni di utilizzo di TicketWave.</p>
        </div>
    )
}
