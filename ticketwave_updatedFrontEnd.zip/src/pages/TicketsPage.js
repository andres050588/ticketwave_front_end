import { useEffect, useState } from "react"
import axios_api from "../api/api.js"
import { Container, Row, Col, Spinner, Alert } from "react-bootstrap"
import TicketCard from "../components/TicketCard.js"

export default function TicketsPage() {
    const [tickets, setTickets] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    useEffect(() => {
        const fetchTickets = async () => {
            try {
                const response = await axios_api.get("/api/tickets")
                setTickets(response.data)
            } catch (err) {
                setError("Errore durante il caricamento dei biglietti.")
            } finally {
                setLoading(false)
            }
        }
        fetchTickets()
    }, [])

    return (
        <Container className="my-5">
            <h2 className="mb-4">Biglietti Disponibili</h2>
            {loading && <Spinner animation="border" />}
            {error && <Alert variant="danger">{error}</Alert>}
            <Row>
                {tickets.map(ticket => (
                    <Col key={ticket.id} md={6} lg={4}>
                        <TicketCard ticket={ticket} />
                    </Col>
                ))}
            </Row>
        </Container>
    )
}
