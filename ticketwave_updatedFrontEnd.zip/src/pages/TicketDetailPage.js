import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { Container, Card, Button, Spinner, Alert } from "react-bootstrap"
import axios_api from "../api/api.js"

export default function TicketDetailPage() {
    const { id } = useParams()
    const navigate = useNavigate()
    const [ticket, setTicket] = useState(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)
    const [success, setSuccess] = useState(null)

    useEffect(() => {
        const fetchTicket = async () => {
            try {
                const response = await axios_api.get(`/api/tickets/${id}`)
                setTicket(response.data)
            } catch (error) {
                setError("Biglietto non trovato")
            } finally {
                setLoading(false)
            }
        }
        fetchTicket()
    }, [id])

    const handlePurchase = async () => {
        const token = localStorage.getItem("token")
        if (!token) {
            navigate("/login")
            return
        }

        try {
            const response = await axios_api.post(
                "/api/orders",
                { ticketId: ticket.id },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            )
            setSuccess("Ordine creato! Hai 15 minuti per completare l'acquisto")
            setTimeout(() => navigate("/orders"), 2000)
        } catch (error) {
            setError(error.response?.data?.error || "Errore durante l'acquisto")
        }
    }

    return (
        <Container className="my-5">
            {loading && (
                <div className="text-center">
                    <Spinner animation="border" />
                </div>
            )}

            {error && <Alert variant="danger">{error}</Alert>}
            {success && <Alert variant="success">{success}</Alert>}

            {ticket && (
                <Card>
                    <Card.Body>
                        <Card.Title>{ticket.title}</Card.Title>
                        <Card.Text>Prezzo: €{ticket.price}</Card.Text>
                        <Card.Text>Stato: {ticket.status}</Card.Text>
                        {ticket.eventDate && (
                            <Card.Text>
                                Data evento:{" "}
                                {new Date(ticket.eventDate).toLocaleString("it-IT", {
                                    day: "2-digit",
                                    month: "2-digit",
                                    year: "numeric",
                                    hour: "2-digit",
                                    minute: "2-digit"
                                })}
                            </Card.Text>
                        )}
                        {ticket.imageURL && <img src={ticket.imageURL} alt={ticket.title} style={{ width: "100%", borderRadius: "12px", marginBottom: "1rem" }} />}
                        {ticket.status === "disponibile" && (
                            <Button variant="success" className="w-100 mt-3" onClick={handlePurchase}>
                                Acquista Ora
                            </Button>
                        )}{" "}
                    </Card.Body>
                </Card>
            )}
        </Container>
    )
}
