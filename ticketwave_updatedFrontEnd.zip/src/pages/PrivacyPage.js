export default function PrivacyPage() {
    return (
        <div className="p-5">
            <h2>Privacy Policy</h2>
            <p>Questa è una pagina informativa sulla nostra politica sulla privacy.</p>
        </div>
    )
}
